#include <mega32.h>
#include <lcd.h>
#include <stdio.h>
#include <delay.h>

#asm(" .equ __lcd_port=0x15");

#define ADC_VREF_TYPE ((0<<REFS1) | (0<<REFS0) | (0<<ADLAR))
float lm35_1 (void);
float lm35_2 (void);
float lm35_3 (void);
bit c=0,mc=0;
int cm=0,ct=0,mt=0,Tc1=27,Tc2=27,Tc3=27;
char    Buffer_LCD[20],buf[20]; 
float   Temperature1,Temperature2,Temperature3;
void Tset(void);
void T1set(void);
void T2set(void);
void T3set(void);
void Mset(void);
void menu(void);
void check (void);
unsigned int read_adc(unsigned char adc_input)
{
ADMUX=adc_input | ADC_VREF_TYPE;
delay_us(10);
ADCSRA|=(1<<ADSC);
while ((ADCSRA & (1<<ADIF))==0);
ADCSRA|=(1<<ADIF);
return ADCW;
}
 
void main(void)
{
DDRD=0xf8;
PORTD=0x07;
DDRB=63;
ADMUX=ADC_VREF_TYPE;
ADCSRA=(1<<ADEN) | (0<<ADSC) | (0<<ADATE) | (0<<ADIF) | (0<<ADIE) | (0<<ADPS2) | (1<<ADPS1) | (0<<ADPS0);
SFIOR=(0<<ADTS2) | (0<<ADTS1) | (0<<ADTS0);
lcd_init(20);
lcd_clear();
 
while (1)
      {
       if (PIND.1==0)
         {
           while(PIND.1==0);
           lcd_clear();
           cm=0;
           c=~c;
           menu(); 
          }
      check();         
      Temperature1=lm35_1();                      
      sprintf(Buffer_LCD,"T1=%3.1f",Temperature1);
      lcd_gotoxy(0,0);    
      lcd_puts(Buffer_LCD);
      lcd_gotoxy(7,0);      
      lcd_putsf("C");      
      lcd_gotoxy(0,1);  
      Temperature2=lm35_2();                      
      sprintf(Buffer_LCD,"T2=%3.1f",Temperature2);
      lcd_puts(Buffer_LCD);
      lcd_gotoxy(7,1);      
      lcd_putsf("C");
      lcd_gotoxy(0,2);  
      Temperature3=lm35_3();                      
      sprintf(Buffer_LCD,"T3=%3.1f",Temperature3);
      lcd_puts(Buffer_LCD);
      lcd_gotoxy(7,2);      
      lcd_putsf("C");
      lcd_gotoxy(0,3);
      if(mc==0)
       {
        sprintf(Buffer_LCD,"summer mode");
        lcd_puts(Buffer_LCD); 
       }
       else
       {
        sprintf(Buffer_LCD,"winter mode");
        lcd_puts(Buffer_LCD);  
       }
      delay_ms(100);               
      }
}
float lm35_1 (void)
{
 int a1=0;
 float temp1=0;
 a1=read_adc(0);        
 temp1=(a1/2.054) ;
 return temp1;
}
float lm35_2 (void)
{
 int a2=0;
 float temp2=0;
 a2=read_adc(1);        
 temp2=(a2/2.054) ;
 return temp2;
}
float lm35_3 (void)
{
 int a3=0;
 float temp3=0;
 a3=read_adc(2);        
 temp3=(a3/2.054) ;
 return temp3;
}
void menu(void)
{
 while(c==1)
 {
 check();         
 Temperature1=lm35_1();
 Temperature2=lm35_2();
 Temperature3=lm35_3();
 if(PIND.2==0)
  {
  while(PIND.2==0);
  cm++;
  lcd_clear();
  if(cm==3)
  cm=0;
  } 
  if(PIND.0==0)
  {
  while(PIND.0==0);
  cm--;
  lcd_clear();
  if(cm<0)
  cm=2;
  }
  if(cm==0)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("   main menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> temp set");
  lcd_gotoxy(0,2);
  lcd_putsf("   mode set");
  lcd_gotoxy(0,3);
  lcd_putsf("   exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    Tset();
   } 
  } 
 if(cm==1)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("   main menu");
  lcd_gotoxy(0,1);
  lcd_putsf("   temp set");
  lcd_gotoxy(0,2);
  lcd_putsf("=> mode set");
  lcd_gotoxy(0,3);
  lcd_putsf("   exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    Mset();
   } 
  }
  if(cm==2)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("   main menu");
  lcd_gotoxy(0,1);
  lcd_putsf("   temp set");
  lcd_gotoxy(0,2);
  lcd_putsf("   mode set");
  lcd_gotoxy(0,3);
  lcd_putsf("=> exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    c=~c;
   } 
  }  
 }
}
void Tset(void)
{
 bit tw=1;
 while(tw==1)
 {
 check();         
 Temperature1=lm35_1();
 Temperature2=lm35_2();
 Temperature3=lm35_3();
  if(PIND.2==0)
  {
  while(PIND.2==0);
  ct++;
  lcd_clear();
  if(ct==4)
  ct=0;
  } 
  if(PIND.0==0)
  {
  while(PIND.0==0);
  ct--;
  lcd_clear();
  if(ct<0)
  ct=3;
  }
  if(ct==0)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("=> temp1 set");
  lcd_gotoxy(0,1);
  lcd_putsf("   temp2 set");
  lcd_gotoxy(0,2);
  lcd_putsf("   temp3 set");
  lcd_gotoxy(0,3);
  lcd_putsf("   exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    T1set();
   } 
  } 
 if(ct==1)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("   temp1 set");
  lcd_gotoxy(0,1);
  lcd_putsf("=> temp2 set");
  lcd_gotoxy(0,2);
  lcd_putsf("   temp3 set");
  lcd_gotoxy(0,3);
  lcd_putsf("   exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    T2set();
   } 
  }
   if(ct==2)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("   temp1 set");
  lcd_gotoxy(0,1);
  lcd_putsf("   temp2 set");
  lcd_gotoxy(0,2);
  lcd_putsf("=> temp3 set");
  lcd_gotoxy(0,3);
  lcd_putsf("   exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    T3set();
   } 
  }  
  if(ct==3)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("   temp1 set");
  lcd_gotoxy(0,1);
  lcd_putsf("   temp2 set");
  lcd_gotoxy(0,2);
  lcd_putsf("   temp3 set");
  lcd_gotoxy(0,3);
  lcd_putsf("=> exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    tw=~tw;
   } 
  }  
 }
}
void T1set(void)
{
 bit tw1=1;
 while(tw1==1)
 {
 check();         
 Temperature1=lm35_1();
 Temperature2=lm35_2();
 Temperature3=lm35_3(); 
  if(PIND.0==0)
  {
  while(PIND.0==0);
   Tc1++;
   lcd_clear();
  }
  if(PIND.2==0)
  {
  while(PIND.2==0);
   Tc1--;
   lcd_clear();
  }
  lcd_gotoxy(0,0);
  lcd_putsf("temp1 set");
  lcd_gotoxy(0,1);
  sprintf(buf,"temp = %d",Tc1);
  lcd_puts(buf);
  if(PIND.1==0)
  {
  while(PIND.1==0);
   tw1=0;
   lcd_clear();
  }
 }
}
void T2set(void)
{
 bit tw2=1;
 while(tw2==1)
 {
 check();         
 Temperature1=lm35_1();
 Temperature2=lm35_2();
 Temperature3=lm35_3();
  if(PIND.0==0)
  {
  while(PIND.0==0);
   Tc2++;
   lcd_clear();
  }
  if(PIND.2==0)
  {
  while(PIND.2==0);
   Tc2--;
   lcd_clear();
  }
  lcd_gotoxy(0,0);
  lcd_putsf("temp2 set");
  lcd_gotoxy(0,1);
  sprintf(buf,"temp = %d",Tc2);
  lcd_puts(buf);
  if(PIND.1==0)
  {
  while(PIND.1==0);
   tw2=0;
   lcd_clear();
  }
 }
}
void T3set(void)
{
 bit tw3=1;
 while(tw3==1)
 {
 check();         
 Temperature1=lm35_1();
 Temperature2=lm35_2();
 Temperature3=lm35_3();
  if(PIND.0==0)
  {
  while(PIND.0==0);
   Tc3++;
   lcd_clear();
  }
  if(PIND.2==0)
  {
  while(PIND.2==0);
   Tc3--;
   lcd_clear();
  }
  lcd_gotoxy(0,0);
  lcd_putsf("temp3 set");
  lcd_gotoxy(0,1);
  sprintf(buf,"temp = %d",Tc3);
  lcd_puts(buf);
  if(PIND.1==0)
  {
  while(PIND.1==0);
   tw3=0;
   lcd_clear();
  }
 }
}
void check (void)
{
 if(mc==0)
 {
  if(Temperature1>=Tc1-1)
  {
  PORTB.0=1;
  }
  if(Temperature1<=Tc1+1)
  {
  PORTB.0=0;
  }
  if(Temperature2>=Tc2-1)
  {
  PORTB.1=1;
  }
  if(Temperature2<=Tc2+1)
  {
  PORTB.1=0;
  }
   if(Temperature3>=Tc3-1)
  {
  PORTB.2=1;
  }
  if(Temperature3<=Tc3+1)
  {
  PORTB.2=0;
  }
 }
 else
 {
  if(Temperature1>=Tc1-1)
  {
  PORTB.3=0;
  }
  if(Temperature1<=Tc1+1)
  {
  PORTB.3=1;
  }
  if(Temperature2>=Tc2-1)
  {
  PORTB.4=0;
  }
  if(Temperature2<=Tc2+1)
  {
  PORTB.4=1;
  }
   if(Temperature3>=Tc3-1)
  {
  PORTB.5=0;
  }
  if(Temperature3<=Tc3+1)
  {
  PORTB.5=1;
  }
 } 
}
void Mset(void)
{
 bit mw=1;
 while(mw==1)
 { 
 check();         
 Temperature1=lm35_1();
 Temperature2=lm35_2();
 Temperature3=lm35_3();
  if(PIND.2==0)
  {
  while(PIND.2==0);
  mt++;
  lcd_clear();
  if(mt==3)
  mt=0;
  } 
  if(PIND.0==0)
  {
  while(PIND.0==0);
  mt--;
  lcd_clear();
  if(mt<0)
  mt=2;
  }
  if(mt==0)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("   mode set");
  lcd_gotoxy(0,1);
  lcd_putsf("=> summer mode");
  lcd_gotoxy(0,2);
  lcd_putsf("   winter mode");
  lcd_gotoxy(0,3);
  lcd_putsf("   exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    mc=0;
    mw=0;
   } 
  } 
 if(mt==1)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("   mode set");
  lcd_gotoxy(0,1);
  lcd_putsf("   summer mode");
  lcd_gotoxy(0,2);
  lcd_putsf("=> winter mode");
  lcd_gotoxy(0,3);
  lcd_putsf("   exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    mc=1;
    mw=0;
   } 
  }
   if(ct==2)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("   mode set");
  lcd_gotoxy(0,1);
  lcd_putsf("   summer mode");
  lcd_gotoxy(0,2);
  lcd_putsf("   winter mode");
  lcd_gotoxy(0,3);
  lcd_putsf("=> exit");
  if (PIND.1==0)
   {
    while(PIND.1==0);
    lcd_clear();
    mw=0;
   } 
  }    
 }
}