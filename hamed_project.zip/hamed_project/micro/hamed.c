#include <mega32.h>
#include <lcd.h>
#include <stdio.h>
#include <delay.h>
void gettemp(void);
void Tmenu(void);
void T1menu(void);
void T2menu(void);
void T3menu(void);
void Mmenu(void);
void gomenu(void);
void check (void);
#asm(" .equ __lcd_port=0x15");
#define ADC_VREF_TYPE ((0<<REFS1) | (0<<REFS0) | (0<<ADLAR))
bit menu=0,modeselect=0;
int menu_location=0,tempmenu=0,modemenu=0,templim1=27,templim2=27,templim3=27,a1=0,a2=0,a3=0,home=0;
char    buf[20]; 
float   Temperature1,Temperature2,Temperature3,temp3=0,temp1=0,temp2=0;
unsigned int read_adc(unsigned char adc_input)
{
ADMUX=adc_input | ADC_VREF_TYPE;
delay_us(10);
ADCSRA|=(1<<ADSC);
while ((ADCSRA & (1<<ADIF))==0);
ADCSRA|=(1<<ADIF);
return ADCW;
}
 
void main(void)
{
ADMUX=ADC_VREF_TYPE;
ADCSRA=(1<<ADEN) | (0<<ADSC) | (0<<ADATE) | (0<<ADIF) | (0<<ADIE) | (0<<ADPS2) | (1<<ADPS1) | (0<<ADPS0);
SFIOR=(0<<ADTS2) | (0<<ADTS1) | (0<<ADTS0);
lcd_init(20);
lcd_clear();
DDRB=0xf8;
PORTB=0x07;
DDRD=63;
while (1)
      {
      check();
      gettemp();
       if (PINB.1==0)
         {
           while(PINB.1==0);
           lcd_clear();
           menu_location=0;
           menu=~menu;
           gomenu(); 
          } 
          if(PINB.2==0)
             {
              while(PINB.2==0);
              home++;
              lcd_clear();
              if(home==3)
              home=0;
              } 
          if(PINB.0==0)
             {
              while(PINB.0==0);
              home--;
              lcd_clear();
              if(home<0)
              home=2;
             } 
     if(home==0)
       {                              
         lcd_gotoxy(0,0);
         if(modeselect==0)
         {
          lcd_puts("summer"); 
         }
         else
         {
          lcd_puts("winter");  
         }          
         lcd_gotoxy(0,1);
         sprintf(buf,"Temp1=%3.1f c",Temperature1);
         lcd_puts(buf);
       }
       if(home==1)
       {                              
         lcd_gotoxy(0,0);
         if(modeselect==0)
         {
          lcd_puts("summer"); 
         }
         else
         {
          lcd_puts("winter");  
         }          
         lcd_gotoxy(0,1);
         sprintf(buf,"Temp2=%3.1f c",Temperature2);
         lcd_puts(buf);
       } 
       if(home==2)
       {                              
         lcd_gotoxy(0,0);
         if(modeselect==0)
         {
          lcd_puts("summer"); 
         }
         else
         {
          lcd_puts("winter");  
         }          
         lcd_gotoxy(0,1);
         sprintf(buf,"Temp3=%3.1f c",Temperature3);
         lcd_puts(buf);
       }                                            
      delay_ms(100);               
      }
}
void gettemp (void)
{
 a1=read_adc(0);        
 temp1=(a1/2.054) ;
 Temperature1=temp1;
 a2=read_adc(1);        
 temp2=(a2/2.054) ;
 Temperature2=temp2; 
 a3=read_adc(2);        
 temp3=(a3/2.054) ;
 Temperature3=temp3;
}
void gomenu(void)
{
 while(menu==1)
 {
 check();         
 gettemp();
 if(PINB.2==0)
  {
  while(PINB.2==0);
  menu_location++;
  lcd_clear();
  if(menu_location==3)
  menu_location=0;
  } 
  if(PINB.0==0)
  {
  while(PINB.0==0);
  menu_location--;
  lcd_clear();
  if(menu_location<0)
  menu_location=2;
  }
  if(menu_location==0)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("main menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> temp menu");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    Tmenu();
   } 
  } 
 if(menu_location==1)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("main menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> mode menu");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    Mmenu();
   } 
  }
  if(menu_location==2)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("main menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> exit");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    menu=~menu;
   } 
  }  
 }
}
void Tmenu(void)
{
 bit tw=1;
 while(tw==1)
 {
 check();
 gettemp();
  if(PINB.2==0)
  {
  while(PINB.2==0);
  tempmenu++;
  lcd_clear();
  if(tempmenu==4)
  tempmenu=0;
  } 
  if(PINB.0==0)
  {
  while(PINB.0==0);
  tempmenu--;
  lcd_clear();
  if(tempmenu<0)
  tempmenu=3;
  }
  if(tempmenu==0)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("temp menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> temp1 set");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    T1menu();
   } 
  } 
 if(tempmenu==1)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("temp menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> temp2 set");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    T2menu();
   } 
  }
   if(tempmenu==2)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("temp menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> temp3 set");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    T3menu();
   } 
  }  
  if(tempmenu==3)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("temp menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> exit");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    tw=~tw;
   } 
  }  
 }
}
void T1menu(void)
{
 bit tw1=1;
 while(tw1==1)
 {
 check();         
 gettemp();
  if(PINB.0==0)
  {
  while(PINB.0==0);
   templim1++;
   lcd_clear();
  }
  if(PINB.2==0)
  {
  while(PINB.2==0);
   templim1--;
   lcd_clear();
  }
  lcd_gotoxy(0,0);
  lcd_putsf("temp1 set");
  lcd_gotoxy(0,1);
  sprintf(buf,"temp = %d",templim1);
  lcd_puts(buf);
  if(PINB.1==0)
  {
  while(PINB.1==0);
   tw1=0;
   lcd_clear();
  }
 }
}
void T2menu(void)
{
 bit tw2=1;
 while(tw2==1)
 {
 check();
 gettemp();         
  if(PINB.0==0)
  {
  while(PINB.0==0);
   templim2++;
   lcd_clear();
  }
  if(PINB.2==0)
  {
  while(PINB.2==0);
   templim2--;
   lcd_clear();
  }
  lcd_gotoxy(0,0);
  lcd_putsf("temp2 set");
  lcd_gotoxy(0,1);
  sprintf(buf,"temp = %d",templim2);
  lcd_puts(buf);
  if(PINB.1==0)
  {
  while(PINB.1==0);
   tw2=0;
   lcd_clear();
  }
 }
}
void T3menu(void)
{
 bit tw3=1;
 while(tw3==1)
 {
 check();         
 gettemp();
  if(PINB.0==0)
  {
  while(PINB.0==0);
   templim3++;
   lcd_clear();
  }
  if(PINB.2==0)
  {
  while(PINB.2==0);
   templim3--;
   lcd_clear();
  }
  lcd_gotoxy(0,0);
  lcd_putsf("temp3 set");
  lcd_gotoxy(0,1);
  sprintf(buf,"temp = %d",templim3);
  lcd_puts(buf);
  if(PINB.1==0)
  {
  while(PINB.1==0);
   tw3=0;
   lcd_clear();
  }
 }
}
void check (void)
{
 if(modeselect==0)
 {
  if(Temperature1>=templim1-1)
  {
  PORTD.0=1;
  PORTD.3=0;
  }
  if(Temperature1<=templim1+1)
  {
  PORTD.0=0;
  PORTD.3=0;
  }
  if(Temperature2>=templim2-1)
  {
  PORTD.1=1;
  PORTD.4=0;
  }
  if(Temperature2<=templim2+1)
  {
  PORTD.1=0;
  PORTD.4=0;
  }
   if(Temperature3>=templim3-1)
  {
  PORTD.2=1;
  PORTD.5=0;
  }
  if(Temperature3<=templim3+1)
  {
  PORTD.2=0;
  PORTD.5=0;
  }
 }
 else
 {
  if(Temperature1>=templim1-1)
  {
  PORTD.3=0;
  PORTD.0=0;
  }
  if(Temperature1<=templim1+1)
  {
  PORTD.3=1;
  PORTD.0=0;
  }
  if(Temperature2>=templim2-1)
  {
  PORTD.4=0;
  PORTD.1=0;
  }
  if(Temperature2<=templim2+1)
  {
  PORTD.4=1;
  PORTD.1=0;
  }
   if(Temperature3>=templim3-1)
  {
  PORTD.5=0;
  PORTD.2=0;
  }
  if(Temperature3<=templim3+1)
  {
  PORTD.5=1;
  PORTD.2=0;
  }
 } 
}
void Mmenu(void)
{
 bit mw=1;
 while(mw==1)
 { 
 check();         
 gettemp();
  if(PINB.2==0)
  {
  while(PINB.2==0);
  modemenu++;
  lcd_clear();
  if(modemenu==3)
  modemenu=0;
  } 
  if(PINB.0==0)
  {
  while(PINB.0==0);
  modemenu--;
  lcd_clear();
  if(modemenu<0)
  modemenu=2;
  }
  if(modemenu==0)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("mode menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> summer mode");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    modeselect=0;
    mw=0;
   } 
  } 
 if(modemenu==1)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("mode menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> winter mode");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    modeselect=1;
    mw=0;
   } 
  }
   if(modemenu==2)
  { 
  lcd_gotoxy(0,0);
  lcd_putsf("mode menu");
  lcd_gotoxy(0,1);
  lcd_putsf("=> exit");
  if (PINB.1==0)
   {
    while(PINB.1==0);
    lcd_clear();
    mw=0;
   } 
  }    
 }
}